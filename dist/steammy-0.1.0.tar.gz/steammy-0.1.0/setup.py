from setuptools import setup

setup(
    name='steammy',
    version='0.1.0',
    description='',
    author='Hungreeee',
    author_email='hungmnguyen13102003@gmail.com',
    license='MIT',
    install_requires=['requests', 'pandas', 'json'],
    python_requires='>=3.5',
)